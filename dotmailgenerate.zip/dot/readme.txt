Dot Mail generator helps to generate dot mail with custom domain and with all possibility.

How it Work

Download the File and Upload it / Can also use on Local Machine

Extract the folder 2.Call the index file 3.Enter email and custom domain or any domain of your choice. 4.It will generate all possibilty.